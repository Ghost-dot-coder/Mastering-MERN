import React from "react";
import Header from "../components/Header";

export default function ProductPage() {
  return (
    <>
      <Header />
      <div className="flex flex-col mx-5">
        <div className="grid grid-cols-2 items-center h-screen">
          <div>
            <img
              width="350px"
              height="250px"
              src="https://cdn.dummyjson.com/product-images/beauty/eyeshadow-palette-with-mirror/thumbnail.webp"
              alt="no image"
            />
            <div className="flex justify-between mt-5">
              <button className="bg-blue-600 text-white p-2 rounded">
                ADD TO WISHLIST
              </button>
              <button className="bg-green-600 text-white p-2 rounded">
                ADD TO CART
              </button>
            </div>
          </div>

          <div>
            <h3 className="font-bold">PID: id</h3>
            <h1 className="text-5xl font-bold">Title</h1>
            <h4 className=" font-bold text-red-600 text-2xl">$230</h4>

            <h4>Brand:</h4>
            <h4>Category:</h4>

            <p>
              <span className="font-bold">
                Description:Lorem ipsum dolor sit amet consectetur adipisicing
                elit. Labore necessitatibus itaque tempora quia repudiandae.
                Ipsa aliquam doloremque recusandae ea ex sit ab necessitatibus
                illo.
              </span>
            </p>
          </div>
        </div>
      </div>
    </>
  );
}