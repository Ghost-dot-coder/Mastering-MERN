import { configureStore } from "@reduxjs/toolkit";

const cartStore = configureStore({
    reducer:{

    }
})
export default cartStore