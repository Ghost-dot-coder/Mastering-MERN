import React from 'react'

const Pnf = () => {
  return (
    <>
    <div className='flex items-center justify-center h-screen w-full'>
        <img height={'400px'} width={'350px'} src="https://i0.wp.com/learn.onemonth.com/wp-content/uploads/2017/08/1-10.png?fit=845%2C503&ssl=1" alt="no image" />
    </div>
    </>
  )
}

export default Pnf